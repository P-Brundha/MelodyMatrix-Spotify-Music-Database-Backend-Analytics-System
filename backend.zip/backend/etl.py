import mysql.connector

# Database connection settings
DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "",  # change if you have a password
    "database": "music_db"
}

def connect_db():
    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        print("Backend is connected")
        return conn
    except mysql.connector.Error as err:
        print(f"Error: {err}")
        exit(1)

def load_data():
    conn = connect_db()
    cursor = conn.cursor()

    # Sample Artist
    artist_data = ("A1", "Taylor Swift", "Pop", 95, 120000000)
    cursor.execute("""
        INSERT INTO artists (artist_id, name, genres, popularity, followers)
        VALUES (%s, %s, %s, %s, %s)
        ON DUPLICATE KEY UPDATE name = VALUES(name)
    """, artist_data)

    # Sample Track
    track_data = ("T1", "Love Story", "Fearless", "2008-09-15", 230000, 90, "A1")
    cursor.execute("""
        INSERT INTO tracks (track_id, name, album, release_date, duration_ms, popularity, artist_id)
        VALUES (%s, %s, %s, %s, %s, %s, %s)
        ON DUPLICATE KEY UPDATE name = VALUES(name)
    """, track_data)

    conn.commit()
    cursor.close()
    conn.close()
    print("Sample data loaded successfully!")

if __name__ == "__main__":
    load_data()
