from flask import Flask, jsonify
import mysql.connector

app = Flask(__name__)

DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "",  # change if you have a password
    "database": "music_db"
}

def get_db_connection():
    return mysql.connector.connect(**DB_CONFIG)

@app.route("/artists", methods=["GET"])
def get_artists():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM artists")
    artists = cursor.fetchall()
    cursor.close()
    conn.close()
    return jsonify(artists)

@app.route("/tracks", methods=["GET"])
def get_tracks():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM tracks")
    tracks = cursor.fetchall()
    cursor.close()
    conn.close()
    return jsonify(tracks)

if __name__ == "__main__":
    app.run(debug=True)
